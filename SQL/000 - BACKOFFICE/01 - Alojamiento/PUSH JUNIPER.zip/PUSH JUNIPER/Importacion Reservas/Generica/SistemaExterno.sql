SELECT * FROM Tbl_SistemaExterno WHERE Id_SEx = 58

SELECT Id_Sex, Coc_DirectorioTemporal, * FROM Tbl_ConfiguracionConexion WHERE Id_Sex = 58


SELECT Id_Sex,Cca_fileKeySeparator,UsrMod, * FROM Tbl_ConfiguracionConexionAgencia WHERE Id_Sex = 58