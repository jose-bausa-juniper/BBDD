/* DECLARAMOS TABLAS INTERMEDIAS Y XMLNS */
DECLARE @XMLNS VARCHAR(MAX) = 'xmlns="http://www.juniper.es/webservice/2010/"';
DECLARE @LOCS TABLE (LOC_JET2 NVARCHAR(200), LOC_W2M NVARCHAR(100));
DECLARE @VILLAS TABLE (PROV VARCHAR(5), ID_VILLA VARCHAR (50), VILLA  VARCHAR (150));
DECLARE @DESCARGAS TABLE (LOC_W2M NVARCHAR(100), LOC_JET2 NVARCHAR(200), ID_HISRET INT, ID_ALO NVARCHAR(100), FECMOD DATETIME);
DECLARE @XMLS TABLE ([XML_ID_HDR] INT, [XMLRQ] XML, [XMLRS] XML);

/* DEFINIMOS LOS LOCALIZADORES A BUSCAR */
INSERT INTO @LOCS
VALUES
('4BR4FJ~50727282~17640627/S25H','R5N4J6'),
('Z2T1D3~50872080~17688328/S25H','CLCQ1Z'),
('FJB4B5~53272770~18478332/S25H',NULL),
(NULL,NULL)
/* EXTRAEMOS LAS VILLAS */
INSERT INTO @VILLAS
	SELECT
		AlE_Prov,
		AlE_Cod,
		AlE_Nombre
	FROM 
		BD_Nincoming.dbo.vwQlik_JP_Externos
	WHERE
		1 = 1
		AND AlE_Prov = 'AVT'

/* EXTRAEMOS LAS DESCARGAS */
INSERT INTO @DESCARGAS
SELECT
	DRe_resLocalizador,
	DRe_codigoExt,
	MAX(DRe_IdHDRRet),
	DRe_IdAlo,
	MAX(FecMod)
FROM 
	BD_Nincoming_HIS.dbo.Tbl_DescargaReserva 
WHERE 
	1 = 1
	AND DRe_CodigoSE = 57 
	AND DRe_IdAlo LIKE '%AVT|%'
GROUP BY
	DRe_resLocalizador,
	DRe_codigoExt,
	DRe_IdAlo

/* EXTRAEMOS LOS XMLS */
INSERT INTO @XMLS
	SELECT
		HDR.id_HDR																								AS [XML_ID_HDR], 
		CAST( REPLACE(CAST((CAST(DECOMPRESS (HDR.HDR_RequestBin)AS XML)) AS NVARCHAR(MAX)), @XMLNS, '') AS XML)	AS [XMLRQ],
		CAST( REPLACE(CAST(CAST(DECOMPRESS (HDR.HDR_ResponseBin) AS XML) AS NVARCHAR(MAX)), @XMLNS, '') AS XML)	AS [XMLRS]
	FROM
		BD_Nincoming_HIS.dbo.Tbl_HistorialDescargaReserva HDR
	WHERE
		1 = 1
		AND HDR.HDR_CodigoSE = 57

SELECT 
	INFO.*
FROM 	
				@LOCS	LOCS
	LEFT JOIN	(SELECT
					DR.LOC_W2M																				AS [LOC W2M],
					DR.LOC_JET2																				AS [FULL LOC JET2],
					DR.ID_ALO																				AS [ID Villa],
					V.VILLA																					AS [Nombre Villa],
					DR.FECMOD																				AS [Fecha Lectura],
					R.value('@Locator'												, 'VARCHAR(20)')		AS [LOC JET2],
					R.value('(Data/ReservationDate)[1]'								, 'DATETIME')			AS [ReservationDate_JET2],
					
					CAST(DATEDIFF(MINUTE, R.value('(Data/ReservationDate)[1]', 'DATETIME'), DR.FECMOD) / 1440 AS VARCHAR) + ' d�as ' +
���					CAST((DATEDIFF(MINUTE, R.value('(Data/ReservationDate)[1]', 'DATETIME'), DR.FECMOD) % 1440) / 60 AS VARCHAR) + ' horas ' +
���					CAST(DATEDIFF(MINUTE, R.value('(Data/ReservationDate)[1]', 'DATETIME'), DR.FECMOD) % 60 AS VARCHAR) + ' minutos' AS DifereceTime,

					R.value('(Data/LastModificationDate)[1]'						, 'DATETIME')			AS [LastModificationDate_JET2],
					R.value('(Data/TimeZone)[1]'									, 'VARCHAR(10)')		AS [TimeZone_JET2],
					R.value('(Elements/ServiceElement/@Id)[1]'						, 'BIGINT')				AS [ID_LRE_JET2],
					R.value('(Elements/ServiceElement/Status)[1]'					, 'VARCHAR(10)')		AS [Status_JET2],
					R.value('(Elements/ServiceElement/@Start)[1]'					, 'DATE')				AS [CheckIn],
					R.value('(Elements/ServiceElement/@End)[1]'						, 'DATE')				AS [CheckOut],
					R.value('(Elements/ServiceElement/Prices/Cost/@Amount)[1]'		, 'FLOAT')				AS [Cost_Amount]
				FROM
								@DESCARGAS															AS DR
					LEFT JOIN	@VILLAS																AS V	ON	RIGHT(DR.ID_ALO , LEN(DR.ID_ALO)-CHARINDEX('|',DR.ID_ALO)) = V.ID_VILLA
					INNER JOIN	@XMLS																AS XMLS	ON  DR.ID_HISRET = XMLS.XML_ID_HDR
					CROSS APPLY 
						[XMLS].[XMLRS].nodes('/ReadServiceResponseReadRS/Reservations/Reservation') AS X(R)
				WHERE
					1 = 1
					AND LEFT(DR.LOC_JET2, CHARINDEX('~', DR.LOC_JET2) - 1) = R.value('@Locator', 'VARCHAR(20)')
					AND DR.LOC_JET2 IN (SELECT LOC_JET2 FROM @LOCS)
				) 
				INFO ON INFO.[FULL LOC JET2] = LOCS.LOC_JET2
WHERE
	1 = 1
	--AND NOT  (INFO.[LOC W2M] IS NULL AND INFO.[Status_JET2] = 'CN')
	--AND INFO.CheckIn >= GETDATE()

/*		W2M		JET2							VILLA			OBSERVACIONES							
		-------------------------------------------------------------------------------------------
*/
-->		NULL	BKX3D7~47876464~				AVT|335471 -->	CANCELADA EN JET2
-->		R5N4J6	4BR4FJ~50727282~17640627/S25H	AVT|413349 -->	NO TIENE CUPO PARA FINAL DE OCTUBRE
-->		CLCQ1Z	Z2T1D3~50872080~17688328/S25H	AVT|398422 -->	NO TIENE CUPO PARA FINAL DE OCTUBRE
-->		NULL	K68Q23~49163894~17121500/S25H	AVT|337816 -->	RESERVA EN PASADO
-->		NULL	55H21D~52627152~18264115/S25H	AVT|495632 -->	NO TIENE CUPO PARA FINAL DE JULIO
